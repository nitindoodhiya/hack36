#!/bin/bash
sudo apt-get update
sudo apt-get install vlc browser-plugin-vlc