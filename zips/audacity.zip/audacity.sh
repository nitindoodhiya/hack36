#!/bin/bash
sudo add-apt-repository ppa:ubuntuhandbook1/audacity
sudo apt-get -y update
sudo apt-get -y install audacity