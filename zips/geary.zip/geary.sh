#!/bin/bash
sudo add-apt-repository ppa:geary-team/releases
sudo apt update
sudo apt install geary