Instructions to install the softwares:
1.open terminal in the folder where these shell files are present.
2.type "chmod +x filename" without inverted commas.
3.type "./filename".
