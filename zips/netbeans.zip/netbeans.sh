#!/bin/bash
sudo apt-get purge openjdk*
sudo apt-get update
sudo apt-get install oracle-java8-installer
wget http://download.netbeans.org/netbeans/8.2/final/bundles/netbeans-8.2-linux.sh
chmod +x netbeans-8.2-linux.sh
./netbeans-8.2-linux.sh
sudo add-apt-repository ppa:vajdics/netbeans-installer
sudo apt update
sudo apt install netbeans-installer