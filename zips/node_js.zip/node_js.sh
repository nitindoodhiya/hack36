#!/bin/bash
sudo apt-get update
sudo apt-get install nodejs
sudo apt-get install npm
sudo apt install nodejs-legacy