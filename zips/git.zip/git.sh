#!/bin/bash
sudo apt-get update
add-apt-repository ppa:git-core/ppa
apt update
apt install git