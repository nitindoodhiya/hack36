#!/bin/bash
sudo apt install chromium-browser