#!/bin/bash
sudo add-apt-repository 'deb http://archive.canonical.com/ precise partner'
sudo apt-get update
sudo apt-get install adobereader-enu
sudo add-apt-repository -r 'deb http://archive.canonical.com/ precise partner'
sudo apt-get update