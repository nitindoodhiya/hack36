#!/bin/bash
wget https://download.teamviewer.com/download/teamviewer_i386.deb
sudo dpkg -i teamviewer*.deb
sudo apt-get -f install